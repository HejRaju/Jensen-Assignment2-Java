
package caw.atm;



public class Main {

    public static void main(String[] args) {
        ATM bankomat = new ATM(new Bank());
        bankomat.Run();
        
    }
}
