
package caw.atm;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

/**
 *
 * @author raju
 */
public class ATMTest {
    
   private Account account;
    
    private ATM atm;
    
    @Before
    public void setUp() {
     List<User> bankUsers = new LinkedList<>();
     List<Account> user1Accounts = new ArrayList<>();
     user1Accounts.add(new Account("123456", 11));
     user1Accounts.add(new Account("987654", 12));
     User user1 = new User("LinusKjellgren", "710305", user1Accounts);
     bankUsers.add(user1);
    }
    
  
    
    @Test
    public void DepositeTest1(){

        
         account = new Account("1234", 0);
         atm = new ATM();
         
         atm.DepositMoney(account, 100);

     Assert.assertEquals(100, account.accountBalance);
         
      
    }
    
    @Test
    public void DepositeTest2(){
     account = new Account("1234", 500);
     atm = new ATM();

     atm.DepositMoney(account, 100);
     Assert.assertEquals(600, account.accountBalance);


    }
    
    @Test
    public void DepositeTest3(){
     account = new Account("1234", 300);
     atm = new ATM();
     atm.DepositMoney(account, 200);
     Assert.assertEquals(500, account.accountBalance);
        
    }
    
    @Test
    public void CheckBalance(){
     account = new Account("1234",0);
     atm = new ATM();

     Assert.assertEquals(0, account.accountBalance);


    }
    @Test
    public void CheckBalancewithWrongAccountnumber(){
     account = new Account("1289",0);
     atm = new ATM();
     Assert.assertEquals(0, account.accountBalance);


    }
    
    @Test
    public void WithdrowTest1(){
     account = new Account("1234", 500);
     atm = new ATM();

     //is withdraw working
     atm.WithdrawMoney(account, 100);
     Assert.assertEquals(500, account.accountBalance);

    }
    @Test
    public void WithdrowmoreThenDepostedTest(){
     account = new Account("1234", 0);
     atm = new ATM();

     atm.DepositMoney(account, 100);
     atm.WithdrawMoney(account, 100);
     Assert.assertEquals(0, account.accountBalance);


    }
    @Test
    public void WithdrowWhenBalanceIs0(){
     account = new Account("1234", 100);
     atm = new ATM();


     atm.WithdrawMoney(account, 100);
     Assert.assertEquals(0, account.accountBalance);


    }

    /* @Test
 public void TestLoginMethod(){
 List<User> bankUsers = new LinkedList<>();
 List<Account> user1Accounts = new ArrayList<>();
     user1Accounts.add(new Account("123456", 11));
     user1Accounts.add(new Account("987654", 12));
 User user1 = new User("LinusKjellgren", "710305", user1Accounts);
     bankUsers.add(user1);

     atm = new ATM();
     result=atm.logIn("LinusKjellgren","710305");
     Assert.assertEquals(LinusKjellgren, result); */


}

