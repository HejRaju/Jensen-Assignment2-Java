package caw.atm;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
/*
import org.junit.Test;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class BankomatTest {
    
    public BankomatTest() {
    }

    @Test
    public void testLogIn_UserExist() {
        IBank bankMock = mock(IBank.class);
        ATM bankomat = new ATM(bankMock);
        
        List<User> bankUsers = new LinkedList<>();
        List<Account> user1Accounts = new ArrayList<>();
        user1Accounts.add(new Account("123456", 11));
        user1Accounts.add(new Account("987654", 12));
        User user1 = new User("LinusKjellgren", "710305", user1Accounts);
        bankUsers.add(user1);
        List<Account> user2Accounts = new ArrayList<>();
        user2Accounts.add(new Account("45753", 101));
        user2Accounts.add(new Account("455543", 102));
        User user2 = new User("KalleSvensson", "Password", user2Accounts);
        bankUsers.add(user2);
        
        when(bankMock.getUsers()).thenReturn(bankUsers);
        User result = bankomat.logIn("KalleSvensson", "Password");
        
        assertAll(()->assertEquals(result.getName(), user2.getName()), 
                ()->assertEquals(result.password, user2.getPassword()), 
                ()->assertEquals(result.getAccounts().get(0).accountNumber, ""+45753), 
                ()->assertEquals(result.getAccounts().get(0).accountBalance, 101), 
                ()->assertEquals(result.getAccounts().get(1).accountNumber, ""+455543),
                ()->assertEquals(result.getAccounts().get(1).accountBalance, 102));
    }
    
}


 */